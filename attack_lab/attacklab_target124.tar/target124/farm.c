/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_120(unsigned *p)
{
    *p = 2496104776U;
}

void setval_276(unsigned *p)
{
    *p = 3281031240U;
}

unsigned getval_139()
{
    return 3633790195U;
}

unsigned getval_107()
{
    return 3347663088U;
}

void setval_200(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_146(unsigned x)
{
    return x + 3277362573U;
}

void setval_250(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_322(unsigned x)
{
    return x + 1217184600U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_127()
{
    return 3374367117U;
}

void setval_218(unsigned *p)
{
    *p = 3286272072U;
}

unsigned getval_356()
{
    return 3229139337U;
}

unsigned addval_302(unsigned x)
{
    return x + 3221801481U;
}

unsigned addval_282(unsigned x)
{
    return x + 3380926089U;
}

unsigned getval_114()
{
    return 2425411081U;
}

void setval_408(unsigned *p)
{
    *p = 3223901833U;
}

unsigned addval_217(unsigned x)
{
    return x + 3281046153U;
}

unsigned getval_156()
{
    return 2497743176U;
}

unsigned getval_349()
{
    return 2425405837U;
}

unsigned getval_150()
{
    return 3534018185U;
}

unsigned getval_151()
{
    return 3526412937U;
}

unsigned addval_425(unsigned x)
{
    return x + 3385120393U;
}

unsigned getval_392()
{
    return 3222853257U;
}

void setval_167(unsigned *p)
{
    *p = 3532964233U;
}

unsigned addval_389(unsigned x)
{
    return x + 3373845129U;
}

unsigned getval_464()
{
    return 3383017865U;
}

unsigned addval_172(unsigned x)
{
    return x + 3281046153U;
}

unsigned getval_354()
{
    return 3372794249U;
}

unsigned getval_446()
{
    return 3524837769U;
}

unsigned getval_244()
{
    return 2447411528U;
}

void setval_171(unsigned *p)
{
    *p = 4190361225U;
}

void setval_460(unsigned *p)
{
    *p = 2497743176U;
}

void setval_439(unsigned *p)
{
    *p = 3372794249U;
}

unsigned addval_272(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_398(unsigned x)
{
    return x + 3286272840U;
}

unsigned addval_449(unsigned x)
{
    return x + 2430638408U;
}

unsigned getval_233()
{
    return 3221801601U;
}

void setval_339(unsigned *p)
{
    *p = 3677935273U;
}

void setval_176(unsigned *p)
{
    *p = 3383020169U;
}

unsigned getval_432()
{
    return 3767093502U;
}

void setval_101(unsigned *p)
{
    *p = 3525888649U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
